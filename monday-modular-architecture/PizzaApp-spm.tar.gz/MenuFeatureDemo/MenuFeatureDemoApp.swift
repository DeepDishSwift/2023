//
//  MenuFeatureDemoApp.swift
//  MenuFeatureDemo
//
//  Created by Ben Scheirman on 4/19/23.
//

import SwiftUI

@main
struct MenuFeatureDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
