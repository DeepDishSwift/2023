//
//  ContentView.swift
//  MenuFeatureDemo
//
//  Created by Ben Scheirman on 4/19/23.
//

import SwiftUI
import MenuFeature
import Models
import SwiftUIHelpers
import EffectsLibrary

struct ContentView: View {
    @State private var presentedExample: Example?
    @State private var showSecretMenu = false
    @State private var showConfetti = false

    enum Example: String, Identifiable, CaseIterable {
        var id: String { rawValue }

        case standardMenu
        case limitedMenu
        case joshMenu

        var title: String {
            switch self {
            case .standardMenu: return "Standard Menu"
            case .limitedMenu: return "Limited Menu"
            case .joshMenu: return "Secret off menu"
            }
        }

        var isSecret: Bool {
            self == .joshMenu
        }

        private var categories: [Models.Category] {
            switch self {
            case .standardMenu: return Category.all
            case .limitedMenu: return Array(Category.all.dropFirst())
            case .joshMenu: return Array([Category.josh])
            }
        }

        var destination: some View {
            MenuTabView(categories: categories)
                .environmentObject(Cart())
        }
    }

    var body: some View {
        List {
            ForEach(Example.allCases.filter { !$0.isSecret || self.showSecretMenu }) { example in
                Button {
                    withAnimation {
                        presentedExample = example
                    }
                } label: {
                    Text("\(example.isSecret ? "🤫" : "") \(example.title)")
                }
            }

        }
        .sheet(item: $presentedExample) { example in
            example.destination
        }
        .onShake {
            withAnimation {
                showSecretMenu = true
                showConfetti = true
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2)) {
                    withAnimation {
                        showConfetti = false
                    }
                }
            }
        }
        .overlay {
            if showConfetti {
                ConfettiView(config: confettiConfig)
                    .offset(.init(width: 0, height: 120))
            } else {
                EmptyView()
            }
        }
    }

    private var confettiConfig: ConfettiConfig {
        .init(content: [.emoji("🍍", 2)],
              intensity: .high,
              lifetime: .long,
              spreadRadius: .high,
              emitterPosition: .top,
              fallDirection: .downwards)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
