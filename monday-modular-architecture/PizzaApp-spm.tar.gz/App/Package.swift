// swift-tools-version: 5.7
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "App",
    platforms: [
        .iOS(.v16)
    ],
    products: [
        .library(name: "Models", targets: ["Models"]),
        .library(name: "MenuFeature", targets: ["MenuFeature"]),
        .library(name: "CheckoutFeature", targets: ["CheckoutFeature"]),
        .library(name: "SwiftUIHelpers", targets: ["SwiftUIHelpers"]),
    ],
    dependencies: [
        .package(url: "https://github.com/pointfreeco/swift-identified-collections", from: "0.7.1"),
        .package(url: "https://github.com/simibac/ConfettiSwiftUI.git", from: "1.0.1"),
        .package(url: "https://github.com/GetStream/effects-library.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "Models",
            dependencies: [
                .product(name: "IdentifiedCollections", package: "swift-identified-collections")
            ]
        ),
        .target(name: "MenuFeature", dependencies: [
            "Models",
            "SwiftUIHelpers",
            .product(name: "EffectsLibrary", package: "effects-library")]),
        .target(name: "CheckoutFeature", dependencies: ["Models"]),
        .target(name: "SwiftUIHelpers", dependencies: [])
    ]
)
