import SwiftUI

public struct MenuItem: Identifiable, Hashable {
    public let id: UUID = .init()
    public let imageName: String
    public let name: String
    public let description: String
    public let price: Decimal
}

extension MenuItem {
    public var image: Image {
        Image(uiImage: ModelResources.image(named: imageName) ?? .init())
    }
}
