import UIKit

public enum ModelResources {
    public static func image(named name: String) -> UIImage? {
        UIImage(named: name, in: .module, with: nil)
    }
}
