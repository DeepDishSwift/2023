import SwiftUI

public struct Category: Identifiable, Hashable {
    public let id: String
    public let name: String
    public let imageName: String
    public let items: [MenuItem]
}

extension Category {
    public var image: Image {
        Image(uiImage: ModelResources.image(named: imageName) ?? .init())
    }
}

extension Category {
    public static var all: [Category] = [
        .init(id: "appetizers", name: "Appetizers", imageName: "mozzarella-sticks", items: [
            MenuItem(imageName: "mozzarella-sticks", name: "Mozzarella Sticks", description: "Deep fried sticks of mozzarella cheese served with marinara sauce for dipping.", price: 8.99),
            MenuItem(imageName: "cheesy-bread", name: "Cheesy Bread", description: "Bread. Topped with cheese. Wait... isn't this just pizza? 🤔", price: 6.99),
            MenuItem(imageName: "pizza-bites", name: "Pizza Bites", description: "Bite sized pizza balls. For when you want to taste a little pizza before your pizza arrives.", price: 10.99)
        ]),
        .init(id: "pizza", name: "Pizza", imageName: "pizza1", items: [
            MenuItem(imageName: "pizza1", name: "Pepperoni", description: "A classic. Spicy salami, cheese, and sauce.", price: 16.99),
            MenuItem(imageName: "pizza1", name: "Margherita", description: "Fresh Basil. Quality Tomatoes. Simply delish.", price: 15.99),
            MenuItem(imageName: "pizza1", name: "Deep Dish", description: "A Chicago staple. Knife and fork recommended. Keep in mind these take a long time to bake.", price: 19.99),
        ]),
        .init(id: "salads", name: "Salads", imageName: "greek-salad", items: [
            MenuItem(imageName: "greek-salad", name: "Greek Salad", description: "Greens with olives, artichoke, and feta.", price: 7.99)
        ]),
        .init(id: "dessert", name: "Dessert", imageName: "tiramisu", items: [
            MenuItem(imageName: "tiramisu", name: "Tiramisu", description: "Espresso soaked & layered lady fingers with cream", price: 8.99)
        ])
    ]

    public static var josh: Category {
        .init(id: "josh", name: "Josh's Favorites", imageName: "josh", items: [
            MenuItem(imageName: "kiwi", name: "Kiwi special", description: "This really hits the spot after a long summer day.", price: 14.49),
            MenuItem(imageName: "banana", name: "Bananarama", description: "'Malin told me about this pizza and it became an instant fav.' - Josh", price: 16.89),
            MenuItem(imageName: "full-english", name: "The Full English", description: "Nothing beats a full english breakfast... on a pizza... for breakfast", price: 28.89),
        ])
    }
}
