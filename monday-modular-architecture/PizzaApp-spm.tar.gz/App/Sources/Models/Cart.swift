import SwiftUI
import IdentifiedCollections

public final class Cart: ObservableObject {
    @Published
    public private(set) var items: IdentifiedArrayOf<CartItem> = .init()

    public init() {
    }

    public func addOrUpdate(item: MenuItem, quantity: Int) {
        precondition(quantity >= 0)

        if quantity == 0 {
            items.remove(id: item.id)
        } else {
            if items.ids.contains(item.id) {
                items[id: item.id]?.quantity = quantity
            } else {
                items.append(.init(item: item, quantity: quantity))
            }
        }
    }

    public func quantityBinding(for item: MenuItem) -> Binding<Int> {
        .init(
            get: {
                self.items[id: item.id]?.quantity ?? 0
            },
            set: { quantity in
                guard quantity >= 0 else { return }

                self.addOrUpdate(item: item, quantity: quantity)
            })
    }

    public func remove(_ item: MenuItem) {
        items.remove(id: item.id)
    }

    public func clear() {
        items = []
    }

    public var total: Decimal {
        items.map(\.item.price).reduce(0, +)
    }
}

public struct CartItem: Identifiable {
    public var id: MenuItem.ID { item.id }

    public let item: MenuItem
    public var quantity: Int

    public var total: Decimal {
        item.price * Decimal(quantity)
    }
}
