import SwiftUI
import Models

public struct MenuItemDetailView: View {
    public let item: MenuItem
    @Binding var quantity: Int

    public init(item: MenuItem, quantity: Binding<Int>) {
        self.item = item
        _quantity = quantity
    }

    public var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                item.image
                    .resizable()
                    .aspectRatio(contentMode: .fit)

                VStack(alignment: .leading, spacing: 12) {
                    Text(item.name)
                        .font(.title)
                        .frame(maxWidth: .infinity)

                    Text(item.description)

                    Text(item.price, format: .currency(code: "USD"))
                        .font(.headline)
                        .foregroundColor(.orange)

                    if quantity == 0 {
                        Button("Add to Order") {
                            quantity += 1
                        }
                        .frame(maxWidth: .infinity, alignment: .trailing)
                        .buttonStyle(.bordered)
                    } else {
                        Stepper("Quantity: \(quantity)", value: $quantity)
                    }

                    Spacer()
                }
                .padding()
            }
        }
    }
}

struct MenuItemDetailView_Previews: View, PreviewProvider {
    @State var quantity = 0
    var body: some View {
        MenuItemDetailView(
            item: Category.all[0].items[0],
            quantity: $quantity
        )
    }

    static var previews: some View {
        Self()
    }
}
