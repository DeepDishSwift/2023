import SwiftUI
import Models

public struct MenuItemsView: View {
    public let title: String
    public let items: [MenuItem]

    public init(title: String, items: [MenuItem]) {
        self.title = title
        self.items = items
    }

    public var body: some View {
        List(items) { item in
            NavigationLink(value: MenuTabView.Route.item(item)) {
                MenuItemRow(item: item)
            }
        }
        .listStyle(.plain)
        .navigationTitle(title)
    }
}

struct MenuItemRow: View {
    let item: MenuItem

    var body: some View {
        HStack(spacing: 20) {
            item.image
                .resizable()
                .aspectRatio(contentMode: .fill)
                .clipShape(RoundedRectangle(cornerRadius: 4))
                .frame(width: 100)
            Text(item.name)
                .font(.headline)
        }
    }
}

struct MenuItemsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            MenuItemsView(
                title: "Appetizers",
                items: Category.all[0].items
            )
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
