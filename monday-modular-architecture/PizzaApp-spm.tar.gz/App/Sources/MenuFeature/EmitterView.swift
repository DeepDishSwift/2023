import SwiftUI
import SpriteKit

public struct EmitterView: View {
    public var body: some View {
        Color.red
    }
}
