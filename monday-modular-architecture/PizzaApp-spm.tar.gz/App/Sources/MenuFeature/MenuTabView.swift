import SwiftUI
import Models

public struct MenuTabView: View {
    enum Route: Hashable, Equatable {
        case category(Models.Category)
        case item(MenuItem)
    }

    let categories: [Models.Category]

    @EnvironmentObject var cart: Cart
    @State private var path: [Route] = []

    public init(categories: [Models.Category]) {
        self.categories = categories
    }

    public var body: some View {
        NavigationStack(path: $path) {
            ScrollView {
                LazyVGrid(columns: [.init(.adaptive(minimum: 170))]) {
                    ForEach(categories) { category in
                        NavigationLink(value: Route.category(category)) {
                            category.image
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .overlay(alignment: .bottom) {
                                    Text(category.name)
                                        .font(.headline)
                                        .foregroundColor(.white)
                                        .padding(4)
                                        .frame(maxWidth: .infinity)
                                        .background(Color.black.opacity(0.4))
                                }
                                .clipShape(RoundedRectangle(cornerRadius: 3))
                        }
                    }
                }
                .padding()
                .navigationDestination(for: Route.self) { path in
                    switch path {
                    case .category(let category):
                        MenuItemsView(title: category.name, items: category.items)

                    case .item(let item):
                        MenuItemDetailView(item: item, quantity: cart.quantityBinding(for: item))
                    }
                }
            }
            .navigationTitle("Menu")
        }
    }
}

struct MenuTabView_Previews: PreviewProvider {
    static var previews: some View {
        MenuTabView(categories: Category.all)
    }
}
