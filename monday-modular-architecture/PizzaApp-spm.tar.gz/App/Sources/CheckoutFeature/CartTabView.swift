import SwiftUI
import Models

public struct CartTabView: View {
    @EnvironmentObject var cart: Cart

    public init() {
    }

    public var body: some View {
        VStack {
            List {
                ForEach(cart.items) { item in
                    HStack {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(item.item.name)
                                .font(.headline)
                            Text("Quantity \(item.quantity)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text("\(item.total, format: .currency(code: "USD"))")
                    }
                    .padding(.vertical, 4)
                    .swipeActions {
                        Button(role: .destructive) {
                            withAnimation {
                                cart.remove(item.item)
                            }
                        } label: {
                            Label("Remove", systemImage: "trash")
                        }
                    }
                }

                Section {
                    HStack {
                        Text("Total: \(cart.total, format: .currency(code: "USD"))")
                        Spacer()
                        Button(action: { }) {
                            Text("Checkout")
                        }
                        .buttonStyle(.borderedProminent)
                    }
                    .padding(.vertical)
                }
            }

        }
    }
}

struct CartTabView_Previews: PreviewProvider {
    static var previews: some View {
        let cart = Cart()
        cart.addOrUpdate(item: Category.all[0].items[0], quantity: 1)
        cart.addOrUpdate(item: Category.all[0].items[1], quantity: 2)

        return CartTabView()
            .environmentObject(cart)
    }
}
