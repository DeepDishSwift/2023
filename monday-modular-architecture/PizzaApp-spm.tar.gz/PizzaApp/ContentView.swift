import SwiftUI
import MenuFeature
import Models
import CheckoutFeature

struct ContentView: View {
    var body: some View {
        TabView {
            MenuTabView(categories: Category.all)
                .tabItem {
                    VStack {
                        Image(systemName: "menucard")
                        Text("Order")
                    }
                }

            CartTabView()
                .tabItem {
                    VStack {
                        Image(systemName: "basket")
                        Text("Checkout")
                    }
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
