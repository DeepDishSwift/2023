import SwiftUI
import Models

@main
struct PizzaAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(Cart())
        }
    }
}
